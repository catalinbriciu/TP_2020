#include <stdio.h>
#include<stdlib.h>

int v1[100];
int n, vf = 0;
int vf2 = 0, v2[100], nr_biti[100];


int push(int x) {
	v1[vf] = x;
	vf++;
	return x;
}


void Punctul_1(int n) {
	
	while (n!= 0) {
		if (n < 8)
			push(n); 
		else
		push(n % 8);
		n = (n-n % 8) / 8;

	}
}
void afisare(int vf) {
	int i;
	for (i = vf; i > 0 ; i--)
		printf( "%d\n", v1[i]);
}

void Punctul_2(int n) {
	int i; 
	for (i = 0; i < vf; i++) {
		while (v1[i] >2 ) {
			if (v1[i] % 2 == 1)
				nr_biti[i] += 1;
			v1[i] = v1[i] / 2;
		}

	}


}
int main() {
	printf("Dati nr n\n");
	scanf("%d\n", &n);
	Punctul_1(n);
	afisare(vf);
}