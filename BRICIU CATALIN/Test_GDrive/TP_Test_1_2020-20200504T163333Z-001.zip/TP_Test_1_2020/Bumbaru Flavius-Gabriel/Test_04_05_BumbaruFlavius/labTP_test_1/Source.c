#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


int main()
{

	system("pause");
	return 0;
}